# Do‘kon paketi: ishga tushirish (3 qism)

Paketda: `index.html` (Telegram do‘kon ilovasi), `bot.py` + `agent.py` + `products.json` (buyurtma boti va AI agent), `rasmlar/` (tovar rasmlari uchun papka).

## 1-qism. Do‘kon ilovasi (GitHub Pages)
1. github.com da repozitoriy oching, `index.html` va `rasmlar` papkasini yuklang.
2. Settings → Pages → Deploy from a branch → main / root → Save.
3. Manzilni nusxalang: `https://FOYDALANUVCHI.github.io/REPOZITORIYA/`

## 2-qism. Bot
1. @BotFather → `/newbot` → token oling.
2. @userinfobot → o‘zingizning ID raqamingizni oling.
3. Botingizni oching va `/start` bosing (shunda bot sizga yoza oladi).

## 3-qism. Botni doim ishlaydigan qilish (Railway yoki Render)
1. railway.app (yoki render.com) da GitHub orqali kiring.
2. Botning fayllari (`bot.py`, `agent.py`, `products.json`, `requirements.txt`, `Procfile`) joylashgan repozitoriyni ulang.
3. Variables (muhit o‘zgaruvchilari) bo‘limiga `.env.example` dagi to‘rt qiymatni kiriting.
4. Deploy bosing. Loglarda “Bot ishga tushdi” chiqsa, tayyor.

## Tekshirish
Botga `/start` yozing → “Do‘konni ochish” tugmasi → buyurtma bering → sizga xabar keladi.
Botga oddiy matn yozing (“500 mingdan arzon palto bormi?”) → AI agent javob beradi.

## Keyin o‘zgartirish
- Mahsulotlar: `index.html` ichidagi `var P=[` ro‘yxati **va** `products.json` (ikkalasini bir xil qiling).
- Rasmlar: `rasmlar/` papkasiga yuklang, nomini `index.html` dagi `img:` ga yozing.
- Do‘kon manzili, ish vaqti: `products.json` dagi `extra_info` ga.
