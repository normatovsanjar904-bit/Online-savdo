# -*- coding: utf-8 -*-
"""
Do‘kon boti: mini ilovadan kelgan buyurtmalarni qabul qiladi.

Sozlash (3 ta qiymat):
  BOT_TOKEN  - @BotFather bergan token
  WEBAPP_URL - GitHub Pages manzilingiz (https://...github.io/...)
  ANTHROPIC_API_KEY - AI agentni yoqadi (bo‘lmasa, agent o‘chiq turadi)
  ADMIN_IDS  - sizning Telegram ID raqamingiz (@userinfobot dan bilib oling).
               Bir nechta bo‘lsa vergul bilan: 111,222

O‘rnatish:   pip install "python-telegram-bot>=21"
Ishga tushirish:   python bot.py
"""
import json
import logging
import os
from pathlib import Path

from telegram import (InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton,
                      ReplyKeyboardMarkup, Update, WebAppInfo)
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler,
                          ContextTypes, MessageHandler, filters)

BOT_TOKEN = os.getenv("BOT_TOKEN", "BU_YERGA_TOKEN_YOZING")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://BU_YERGA_MANZIL_YOZING")
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "123456789").split(",") if x.strip()]
DB_FILE = Path(os.getenv("DB_FILE", "orders.json"))

STATUS = {
    "new": "🆕 Yangi",
    "accepted": "✅ Qabul qilindi",
    "shipping": "🚚 Yo‘lda",
    "done": "📦 Yetkazildi",
    "cancel": "❌ Bekor qilindi",
}
CUSTOMER_MSG = {
    "accepted": "Buyurtmangiz qabul qilindi va tayyorlanmoqda.",
    "shipping": "Buyurtmangiz yo‘lga chiqdi.",
    "done": "Buyurtmangiz yetkazildi. Xaridingiz uchun rahmat!",
    "cancel": "Afsuski, buyurtmangiz bekor qilindi. Savollar bo‘lsa, biz bilan bog‘laning.",
}

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("dokon-bot")


# ---------- Ma’lumotlar ombori (oddiy JSON fayl) ----------
def load_db() -> dict:
    if DB_FILE.exists():
        try:
            return json.loads(DB_FILE.read_text(encoding="utf-8"))
        except Exception:
            log.exception("orders.json o‘qilmadi")
    return {}


def save_db(db: dict) -> None:
    DB_FILE.write_text(json.dumps(db, ensure_ascii=False, indent=1), encoding="utf-8")


def money(n) -> str:
    return f"{int(n):,}".replace(",", " ") + " so‘m"


def order_text(o: dict) -> str:
    lines = [f"🛍 Buyurtma №{str(o['id'])[-5:]}   {STATUS[o['status']]}", ""]
    for i in o.get("items", []):
        lines.append(f"• {i['name']} × {i['qty']} = {money(i['price'] * i['qty'])}")
    lines.append("")
    if o.get("discount"):
        lines.append(f"Chegirma: −{money(o['discount'])}" + (f" ({o['promo']})" if o.get("promo") else ""))
    lines.append(f"Yetkazib berish: {money(o['delivery']) if o.get('delivery') else 'Bepul'}")
    lines.append(f"💰 Jami: {money(o['total'])}")
    lines.append("")
    lines.append(f"👤 {o.get('name', '-')}")
    lines.append(f"📞 {o.get('phone', '-')}")
    if o.get("deliv") == "pickup":
        lines.append("🏬 Olib ketadi")
    else:
        lines.append(f"📍 {o.get('address', '-')}")
    lines.append("💳 Karta (qabul qilganda)" if o.get("pay") == "card" else "💵 Naqd")
    if o.get("source") == "agent":
        lines.append("🤖 AI agent qabul qildi")
    if o.get("username"):
        lines.append(f"Telegram: @{o['username']}")
    return "\n".join(lines)


def order_buttons(oid: str, status: str):
    def b(text, code):
        return InlineKeyboardButton(text, callback_data=f"st:{oid}:{code}")
    if status == "new":
        rows = [[b("✅ Qabul qilish", "accepted"), b("❌ Bekor", "cancel")]]
    elif status == "accepted":
        rows = [[b("🚚 Yo‘lga chiqdi", "shipping"), b("📦 Yetkazildi", "done")], [b("❌ Bekor", "cancel")]]
    elif status == "shipping":
        rows = [[b("📦 Yetkazildi", "done")], [b("❌ Bekor", "cancel")]]
    else:
        return None
    return InlineKeyboardMarkup(rows)


# ---------- Buyruqlar ----------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Buyurtma botga kelishi uchun ilova aynan shu tugma orqali ochilishi shart.
    kb = ReplyKeyboardMarkup(
        [[KeyboardButton("🛍 Do‘konni ochish", web_app=WebAppInfo(url=WEBAPP_URL))]],
        resize_keyboard=True,
    )
    text = "Assalomu alaykum! Do‘konni ochish uchun pastdagi tugmani bosing."
    if update.effective_user.id in ADMIN_IDS:
        text += "\n\nSiz adminsiz. Buyurtmalar shu yerga keladi.\n/buyurtmalar — oxirgi buyurtmalar"
    await update.message.reply_text(text, reply_markup=kb)


async def my_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"Sizning ID raqamingiz: {update.effective_user.id}")


async def list_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return
    db = load_db()
    if not db:
        await update.message.reply_text("Hali buyurtma yo‘q.")
        return
    last = sorted(db.values(), key=lambda x: x["id"], reverse=True)[:10]
    text = "\n".join(
        f"№{str(o['id'])[-5:]} · {STATUS[o['status']]} · {o.get('name', '-')} · {money(o['total'])}"
        for o in last
    )
    await update.message.reply_text("Oxirgi buyurtmalar:\n\n" + text)


# ---------- Buyurtmani saqlash va adminga yuborish (ilova ham, AI agent ham ishlatadi) ----------
async def submit_order(bot, o: dict, user_id: int, username: str | None) -> dict:
    o["status"] = "new"
    o["user_id"] = user_id
    o["username"] = username or ""
    o["admin_msgs"] = []
    for admin in ADMIN_IDS:
        try:
            sent = await bot.send_message(admin, order_text(o), reply_markup=order_buttons(o["id"], "new"))
            o["admin_msgs"].append([admin, sent.message_id])
        except Exception:
            log.exception("Adminga yuborilmadi: %s (admin botni /start qilganmi?)", admin)
    db = load_db()
    db[o["id"]] = o
    save_db(db)
    return o


async def notify_admins(bot, text: str):
    for admin in ADMIN_IDS:
        try:
            await bot.send_message(admin, text)
        except Exception:
            log.exception("Adminga xabar bormadi: %s", admin)


# ---------- AI agent (oddiy matnli xabarlar) ----------
AGENT_ON = bool(os.getenv("ANTHROPIC_API_KEY"))


async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not AGENT_ON:
        await update.message.reply_text("Do‘konni ochish uchun /start bosing.")
        return
    import agent
    u = update.effective_user
    await context.bot.send_chat_action(update.effective_chat.id, "typing")

    async def submit(o):
        order = await submit_order(context.bot, o, u.id, u.username)
        await context.bot.send_message(u.id, f"✅ Buyurtmangiz №{order['id'][-5:]} qabul qilindi. Jami: {money(order['total'])}")
        return order

    async def notify(t):
        await notify_admins(context.bot, t + (f"\n@{u.username}" if u.username else f"\nID: {u.id}"))

    answer = await agent.reply(u.id, u.first_name or "mijoz", update.message.text, submit, notify)
    await update.message.reply_text(answer)


# ---------- Yangi buyurtma (mini ilovadan) ----------
async def on_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    try:
        o = json.loads(msg.web_app_data.data)
        assert isinstance(o.get("items"), list) and o["items"] and int(o["total"]) > 0
        o["id"] = str(o["id"])
    except Exception:
        log.exception("Noto‘g‘ri buyurtma ma’lumoti")
        await msg.reply_text("Buyurtmani o‘qib bo‘lmadi. Iltimos, qayta urinib ko‘ring.")
        return

    await submit_order(context.bot, o, update.effective_user.id, update.effective_user.username)

    await msg.reply_text(
        f"✅ Buyurtmangiz №{o['id'][-5:]} qabul qilindi!\n"
        f"Jami: {money(o['total'])}\nTez orada siz bilan bog‘lanamiz."
    )


# ---------- Admin tugmalari ----------
async def on_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if q.from_user.id not in ADMIN_IDS:
        await q.answer("Ruxsat yo‘q", show_alert=True)
        return
    _, oid, code = q.data.split(":")
    db = load_db()
    o = db.get(oid)
    if not o or code not in STATUS:
        await q.answer("Buyurtma topilmadi", show_alert=True)
        return
    o["status"] = code
    save_db(db)
    await q.answer(STATUS[code])

    for chat_id, message_id in o.get("admin_msgs", []):
        try:
            await context.bot.edit_message_text(
                order_text(o), chat_id=chat_id, message_id=message_id,
                reply_markup=order_buttons(oid, code),
            )
        except Exception:
            pass  # matn o‘zgarmagan bo‘lsa Telegram xato beradi, bu normal

    if code in CUSTOMER_MSG:
        try:
            await context.bot.send_message(
                o["user_id"], f"Buyurtma №{oid[-5:]}: {CUSTOMER_MSG[code]}"
            )
        except Exception:
            log.warning("Mijozga xabar yuborilmadi")


def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("id", my_id))
    app.add_handler(CommandHandler("buyurtmalar", list_orders))
    app.add_handler(MessageHandler(filters.StatusUpdate.WEB_APP_DATA, on_order))
    app.add_handler(CallbackQueryHandler(on_status, pattern=r"^st:"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    log.info("Bot ishga tushdi")
    app.run_polling()


if __name__ == "__main__":
    main()
